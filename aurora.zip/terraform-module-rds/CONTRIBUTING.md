# Contributing

## Requirements
<!--

List out any software requirements for running this project locally, for example:

* Ruby 3.0
* Postgresql 11.2
* Cassandra 9.0

For bonus points, explain how to install each.

-->

## Installation
<!--

Use this section to list out steps that are needed to setup this project locally. For example:

* Cloning the repository
* Running `bundle install`

-->

## Usage
<!--

Use this section to explain how to run the app after it's installed.

-->

## Testing
<!--

Use this section to explain how to run the tests

-->

## Branches & pull requests
We use the git-flow branch strategy. Features should be based off the `develop` branch and merged using GitHub pull requests.


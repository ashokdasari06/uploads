# terraform-module-rds
Terraform module to create and manage AWS RDS Resources
## Usage
Please refer to https://learn.mdsol.com/display/PEDEVOPSgld/Github+Actions for setting up your repository to use GitHub Actions and Terraform reusable workflow

Also checkout the examples directory.

Referencing this module in your main.tf file
module "rds" {
    source = "git::https://github.com/mdsol/terraform-module-rds.git//module?ref=v1.0.0"
  }
## Note:
Supports terraform provider aws version 5.84.0.
Supports terraform version 1.10.5 or above
## Variable description

### Required Variables
| Variable Name    | Type | Description | Default |
| -------------- | --------- | ------- | ------ |
| create | bool | Set to true to create the resources in the module. Helpful when certain environments don't need the resources | true |
| vpc_name | string | The name of the vpc where RDS instance should be provisioned | medistrano |
| identifier | string | The RDS instance name |
| allocated_storage | string | Storage needed to be allocated to the RDS instance in Gb |
| engine | string | The database engine to use |
| engine_version | string | The database engine version |
| primary_db_instance_class | string | The instance type for the primary RDS instance |
| replica_db_instance_class | string |The instance type for the replica RDS instance/s. If not set primary_db_instance_class will be used |
| replica_count | number | The number of read replicas to create |
| db_name | string | The database name to create within the rds instance |
| username | string | username for the master DB user. Use secret vars structure to define this in a secure way |
| password | string | password for the master DB user. Use secret vars structure to define this in a secure way |
| vpc_security_group_ids | list(string) | List of VPC security groups to associate the RDS instance with |
| subnet_group_name | string | "Name of DB subnet group. DB instance will be created in the VPC associated with the DB subnet group. If unspecified, a new subnet group will be created for you | |

### Optional variables
| Variable Name    | Type | Description | default |
| -------------- | --------- | ------- | ------- |
| secondary_region | string | The region for the cross-region read replica | us-west-2 |
| storage_type | string | One of 'standard' (magnetic), 'gp2' (general purpose SSD), 'gp3' or 'io1' (provisioned IOPS SSD). The default is 'io1' if iops is specified, 'gp2' if not |
| private_subnet_ids | list(string) | list of private subnet ids to spin up the rds cluster in. Note. only specify if your private subnets do not have the following tag aws:cloudformation:logical-id | [] |
| iops | number | The amount of provisioned IOPS. Setting this implies a storage_type of 'io1' |
| storage_encrypted | bool | Specifies whether the DB instance is encrypted |
| skip_final_snapshot | bool | set to true to disable creating a final snapshot before destroy(never set to true beyond POC) | false |
| kms_key_id | string | The ARN for the KMS encryption key. If creating an encrypted replica, set this to the destination KMS ARN. If storage_encrypted is set to true and kms_key_id is not specified the default KMS key created in your account will be used |
| license_model | string | "License model information for this DB instance. Optional, but required for some DB engines, i.e. Oracle SE1 |
| replicate_count | number | Specifies the number of replicas to create for the database | 0 |
| port | number | The port on which the DB accepts connections. If not set the default port for the database engine will be used |
| replica_mode | string | Specifies whether the replica is in either mounted or open-read-only mode. This attribute is only supported by Oracle instances. Oracle replicas operate in open-read-only mode unless otherwise specified |
| iam_database_authentication_enabled | bool | Specifies whether or not the mappings of AWS Identity and Access Management (IAM) accounts to database accounts are enabled |
| domain | string | The ID of the Directory Service Active Directory domain to create the instance in |
| domain_iam_role_name | string | (Required if domain is provided) The name of the IAM role to be used when making API calls to the Directory Service |
| snapshot_identifier | string | Specifies whether or not to create this database from a snapshot. This correlates to the snapshot ID you'd find in the RDS console, e.g: rds:production-2015-06-26-06-05 |
| copy_tags_to_snapshot | bool | On delete, copy all Instance tags to the final snapshot | true |
| preferred_availability_zones | list(string) | The list of availability zones where the RDS instances need to be stood up |
| multi_az | bool | Specifies if the RDS instance is multi-AZ |
| enable_primary_delete_protection | bool | Sets deletion protection for the instance. If deletion protection has been enabled (set to true), deletion is a two step process requiring first setting deletion protection to false and applying the change. After this is done a follow up change can be applied to destroy the rds instance resource. Also note that enable_replica_delete_protection may need to be updated to delete any replicas. | false |
| enable_replica_delete_protection | bool | Sets deletion protection for the replica(s). If deletion protection has been enabled (set to true), deletion is a two step process requiring first setting deletion protection to false and applying the change. After this is done a follow up change can be applied to destroy the rds instance resource. | false |
| enabled_cloudwatch_logs_exports | list | Enable exporting RDS logs to cloudwatch. values includes audit,error,general,slowquery | [] |
| aurora_serverless_autoscaling_min_capacity | number | If using Aurora Serverless, the minimum permitted capacity for the autoscaling engine | null |
| aurora_serverless_autoscaling_max_capacity | number | If using Aurora Serverless, the maximum permitted capacity for the autoscaling engine | null |
| cross_region_vpc_name | string | VPC Name where cross region rds cluster/instances needs to be provisioned |
| cross_region_replica_count | number | The number of replicas needed in the secondary region | 0 |
| cross_region_private_subnet_ids | list(string) | list of private subnet ids in the secondary region to spin up the rds cluster in. Note. only specify if your private subnets do not have the following tag aws:cloudformation:logical-id | [] |
| cross_region_vpc_security_group_ids | list(string) | List of VPC security groups in the secondary region to associate the RDS instance with |

### Enhanced Monitoring and alerting
| Variable Name    | Type | Description | default |
| -------------- | --------- | ------- | ------- |
| enable_enhanced_monitoring | bool | Set to true to enable enhanced monitoring | false |
| enable_cloudwatch_alarms | bool | Set to true to create cloudwatch alarms. Please refer to module/cloudwatch-alarms.tf for the alarms supported | false |
| enable_alerts | bool | Set to true to create SNS topics to alert via email | false |
| alerts_emails | list(string) | List of emails to send alerts. We recommend your team's email PDL and slack app(email integration) tied to your team's slack channel. Required when enable_alerts is set to true | null |
| cpu_utilization_threshold | number | The maximum percentage of CPU utilization. Alerts triggered if cpu utilization is beyond this threshold | 80 |
| disk_queue_depth_threshold | number | The maximum number of outstanding IOs (read/write requests) waiting to access the disk. | 64 |
| freeable_memory_threshold | number | The minimum amount of available random access memory in Byte.| 64000000 |
| free_storage_space_threshold | number | The minimum amount of available storage space in Byte. | 2000000000 |
| swap_usage_threshold | number | The maximum amount of swap space used on the DB instance in Byte. | 256000000 |


## Contributing
See [CONTRIBUTING](CONTRIBUTING.md).

## Contact
See the [factbook](factbook.yaml).

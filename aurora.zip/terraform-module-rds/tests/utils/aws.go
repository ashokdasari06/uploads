package utils

import (
	"context"
	"fmt"
	"log"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/service/ec2"
	"github.com/aws/aws-sdk-go-v2/service/ec2/types"
)

var DefaultRegion = aws.String("us-east-1") // Default region
// var DefaultCredentials = aws.Credentials{
// 	AccessKeyID:     "test",
// 	SecretAccessKey: "test",
// 	SessionToken:    "test",
// }

func getAWSConfig() aws.Config {

	cfg, err := config.LoadDefaultConfig(context.TODO(),
		config.WithRegion(*DefaultRegion),
		// config.WithCredentialsProvider(credentials.StaticCredentialsProvider{
		// 	Value: DefaultCredentials,
		// }),
	)
	if err != nil {
		log.Fatalf("failed to load AWS config: %v", err)
	}
	return cfg
}

func CreateVpcE() (*types.Vpc, error) {
	// Configure the AWS SDK
	cfg := getAWSConfig()

	// Create an EC2 client
	ec2Client := ec2.NewFromConfig(cfg)

	// Create VPC input parameters
	input := &ec2.CreateVpcInput{
		CidrBlock: aws.String("10.0.0.0/16"),
		TagSpecifications: []types.TagSpecification{
			{
				ResourceType: types.ResourceTypeVpc,
				Tags: []types.Tag{
					{
						Key:   aws.String("Name"),
						Value: aws.String("TerratestVPC"),
					},
				},
			},
		},
	}

	// Create the VPC
	result, err := ec2Client.CreateVpc(context.TODO(), input)
	if err != nil {
		return nil, fmt.Errorf("failed to create VPC: %v", err)
	}

	log.Printf("Successfully created VPC with ID: %s", *result.Vpc.VpcId)
	return result.Vpc, nil
}

func DeleteVpcE(vpcID string) error {
	// Configure the AWS SDK
	cfg := getAWSConfig()

	// Create an EC2 client
	ec2Client := ec2.NewFromConfig(cfg)

	// Create delete VPC input parameters
	input := &ec2.DeleteVpcInput{
		VpcId: aws.String(vpcID),
	}

	// Delete the VPC
	_, err := ec2Client.DeleteVpc(context.TODO(), input)
	if err != nil {
		return fmt.Errorf("failed to delete VPC: %v", err)
	}

	log.Printf("Successfully deleted VPC with ID: %s", vpcID)
	return nil
}

func CreateSecurityGroupE(vpcID string) (*ec2.CreateSecurityGroupOutput, error) {
	// Configure the AWS SDK
	cfg := getAWSConfig()

	// Create an EC2 client
	ec2Client := ec2.NewFromConfig(cfg)

	// Create SecurityGroup input parameters
	input := &ec2.CreateSecurityGroupInput{
		GroupName:   aws.String("terratest-sg"),
		Description: aws.String("terratest security group"),
		VpcId:       aws.String(vpcID),
	}

	// Create the SecurityGroup
	sgOutput, err := ec2Client.CreateSecurityGroup(context.TODO(), input)
	if err != nil {
		return nil, fmt.Errorf("failed to create Security Group: %v", err)
	}

	sg := *sgOutput

	log.Printf("Successfully created Security Group with ID: %v", *sg.GroupId)
	return &sg, nil
}

func DeleteSecurityGroupE(groupID string) error {
	// Configure the AWS SDK
	cfg := getAWSConfig()

	// Create an EC2 client
	ec2Client := ec2.NewFromConfig(cfg)

	// Create SecurityGroup input parameters
	input := &ec2.DeleteSecurityGroupInput{
		GroupId: aws.String(groupID),
	}

	// Create the SecurityGroup
	_, err := ec2Client.DeleteSecurityGroup(context.TODO(), input)
	if err != nil {
		return fmt.Errorf("failed to create Security Group: %v", err)
	} else {
		log.Printf("Successfully deleted Security Group with ID: %v", groupID)
		return nil
	}

}

func GetSecurityGroupByID(sgID string) (*ec2.DescribeSecurityGroupsOutput, error) {
	// Configure the AWS SDK
	cfg := getAWSConfig()

	sgFilterValues := []string{sgID}
	sgFilter := types.Filter{Name: aws.String("group-id"), Values: sgFilterValues}
	sgFiltersSlice := []types.Filter{sgFilter}

	// Create an EC2 client
	ec2Client := ec2.NewFromConfig(cfg)

	// Create SecurityGroup input parameters
	input := &ec2.DescribeSecurityGroupsInput{
		Filters: sgFiltersSlice,
	}

	// Describe SecurityGroup
	securityGroup, err := ec2Client.DescribeSecurityGroups(context.TODO(), input)
	if err != nil {
		return nil, fmt.Errorf("failed to get Security Group: %v", err)
	} else {
		return securityGroup, nil
	}

}

func GetSecurityGroupByName(sgName string) (*ec2.DescribeSecurityGroupsOutput, error) {
	// Configure the AWS SDK
	cfg := getAWSConfig()

	sgFilterValues := []string{sgName + "*"}
	sgFilter := types.Filter{Name: aws.String("group-name"), Values: sgFilterValues}
	sgFiltersSlice := []types.Filter{sgFilter}

	// Create an EC2 client
	ec2Client := ec2.NewFromConfig(cfg)

	// Create SecurityGroup input parameters
	input := &ec2.DescribeSecurityGroupsInput{
		Filters: sgFiltersSlice,
	}

	// Describe SecurityGroup
	securityGroup, err := ec2Client.DescribeSecurityGroups(context.TODO(), input)
	if err != nil {
		return nil, fmt.Errorf("failed to get Security Group: %v", err)
	} else {
		return securityGroup, nil
	}

}

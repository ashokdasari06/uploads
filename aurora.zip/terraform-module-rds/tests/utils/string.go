package utils

import (
	"strings"
)

func StringToArray(input string, delimiter string) []string {

	trimInput := strings.Trim(input, "[]")
	trimInput = strings.Trim(trimInput, " ")
	var output []string

	arrInput := strings.Split(trimInput, delimiter)
	for _, item := range arrInput {
		output = append(output, strings.Trim(item, " "))
	}
	return output
}

func GetAttributeFromObjectArray[input any, output any](objectArray []input, f func(input) output) []output {

	var results []output

	for _, item := range objectArray {
		results = append(results, f(item))
	}
	return results
}

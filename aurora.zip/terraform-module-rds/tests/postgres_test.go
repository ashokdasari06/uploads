package tests

import (
	"log"
	"strconv"
	"testing"

	ec2Types "github.com/aws/aws-sdk-go-v2/service/ec2/types"
	rdsTypes "github.com/aws/aws-sdk-go-v2/service/rds/types"
	"github.com/gruntwork-io/terratest/modules/aws"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/mdsol/terraform-module-rds/utils"
	"github.com/stretchr/testify/assert"
)

// An example of how to test the Terraform module in examples/terraform-aws-rds-example using Terratest.
func TestTerraformAwsPostgresExample(t *testing.T) {
	t.Parallel()

	vpcID := "vpc-05bc01157170b0dd3"

	// Use us-east-1 as default region as we may not have access to other regions
	awsRegion := "us-east-1"

	// Construct the terraform options with default retryable errors to handle the most common retryable errors in
	// terraform testing.
	terraformOptions := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		// The path to where our Terraform code is located
		TerraformDir: "../examples/rds-postgres",

		// Variables to pass to our Terraform code using -var options
		// "username" and "password" should not be passed from here in a production scenario.
		Vars: map[string]interface{}{
			"vpc_id":                 vpcID,
			"db_security_group_name": "terratest-sg-rds-pg",
			"skip_final_snapshot":    true,
			"db_allocated_storage":   25,
		},
	})

	// At the end of the test, run `terraform destroy` to clean up any resources that were created
	defer terraform.Destroy(t, terraformOptions)

	// This will run `terraform init` and `terraform apply` and fail the test if there are any errors
	terraform.InitAndApplyAndIdempotent(t, terraformOptions)

	// Run `terraform output` to get the value of an output variable
	dbInstanceID_primary := terraform.Output(t, terraformOptions, "primary_db_instance_id")
	dbInstanceIDs_replica := terraform.Output(t, terraformOptions, "replica_db_instance_id")

	// Get RDS instance details
	instanceDetails, err := aws.GetRdsInstanceDetailsE(t, dbInstanceID_primary, awsRegion)
	if err != nil {
		t.Fatalf("Error creating RDS instance: %v", err)
	}
	log.Printf("%+v\n", instanceDetails)

	allocatedStorage := instanceDetails.AllocatedStorage
	assert.Equal(t, int32(25), *allocatedStorage)

	dbEngine := instanceDetails.Engine
	assert.Equal(t, "postgres", *dbEngine)

	dbEngineVersion := instanceDetails.EngineVersion
	assert.Contains(t, *dbEngineVersion, "14")

	dbInstanceClass := instanceDetails.DBInstanceClass
	assert.Equal(t, "db.t3.micro", *dbInstanceClass)

	dbName := instanceDetails.DBName
	assert.Equal(t, "mydb", *dbName)

	dbSubnetGroup := instanceDetails.DBSubnetGroup
	assert.Equal(t, "all-rds", *dbSubnetGroup.DBSubnetGroupName)

	vpcSecurityGroups := instanceDetails.VpcSecurityGroups
	securityGroupIDs := utils.GetAttributeFromObjectArray(vpcSecurityGroups, func(f rdsTypes.VpcSecurityGroupMembership) string {
		return *f.VpcSecurityGroupId
	})

	// Get securitygroup names to assert on
	sgNames := []string{}
	for _, sgID := range securityGroupIDs {
		securityGroup, _ := utils.GetSecurityGroupByID(sgID)
		groupName := utils.GetAttributeFromObjectArray(securityGroup.SecurityGroups, func(f ec2Types.SecurityGroup) string {
			return *f.GroupName
		})
		sgNames = append(sgNames, groupName...)
	}
	assert.Contains(t, sgNames, "terratest-sg-rds-pg")

	// Look up the endpoint address and port of the RDS instance
	address := aws.GetAddressOfRdsInstance(t, dbInstanceID_primary, awsRegion)
	port := aws.GetPortOfRdsInstance(t, dbInstanceID_primary, awsRegion)

	// Lookup parameter values. All defined values are strings in the API call response
	maxConnectionsParamValue := aws.GetParameterValueForParameterOfRdsInstance(t, "max_connections", dbInstanceID_primary, awsRegion)
	maxWALSizeParamValue := aws.GetParameterValueForParameterOfRdsInstance(t, "max_wal_size", dbInstanceID_primary, awsRegion)

	// Verify that the address is not null
	assert.NotNil(t, address)
	// Verify that the DB instance is listening on the port mentioned
	assert.Equal(t, int32(5432), port)

	// max_connections = LEAST({DBInstanceClassMemory/9531392},5000)
	maxConnections, _ := strconv.ParseInt(maxConnectionsParamValue, 10, 64)
	assert.GreaterOrEqual(t, int64(5000), maxConnections)
	// max_wal_size = 2048
	assert.Equal(t, "2048", maxWALSizeParamValue)

	// Verify that the dbInstanceIDs_replica is not null
	replicasList := utils.StringToArray(dbInstanceIDs_replica, " ")
	assert.NotNil(t, replicasList)
	assert.Equal(t, 2, len(replicasList))
}

func TestTerraformAwsPostgres_invalidVPC(t *testing.T) {

	// Construct the terraform options with default retryable errors to handle the most common retryable errors in
	// terraform testing.
	terraformOptions := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		// The path to where our Terraform code is located
		TerraformDir: "../examples/rds-postgres",

		// Variables to pass to our Terraform code using -var options
		// "username" and "password" should not be passed from here in a production scenario.
		Vars: map[string]interface{}{
			"vpc_id":                  "vpc-platform-devops",
			"db_security_group_name":  "terratest-sg-rds-pg",
			"db_password":             "devops_test",
			"replica_count":           2,
			"skip_final_snapshot":     true,
			"db_parameter_group_name": "default.postgres14",
			"db_identifier":           "iac-postgres-test-invalid-vpc",
		},
	})

	// At the end of the test, run `terraform destroy` to clean up any resources that were created
	defer terraform.Destroy(t, terraformOptions)

	// This will run `terraform init` and `terraform apply` and fail the test if there are any errors
	_, err := terraform.InitAndApplyE(t, terraformOptions)

	if err == nil {
		t.Fatal()
	}

}

func TestTerraformAwsPostgres_invalidParameterGroup(t *testing.T) {

	// Construct the terraform options with default retryable errors to handle the most common retryable errors in
	// terraform testing.
	terraformOptions := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		// The path to where our Terraform code is located
		TerraformDir: "../examples/rds-postgres",

		// Variables to pass to our Terraform code using -var options
		// "username" and "password" should not be passed from here in a production scenario.
		Vars: map[string]interface{}{
			"vpc_id":                  "vpc-05bc01157170b0dd3",
			"db_security_group_name":  "terratest-sg-rds-postgres",
			"db_password":             "devops_test",
			"replica_count":           2,
			"skip_final_snapshot":     true,
			"db_parameter_group_name": "platform-devops",
			"db_identifier":           "iac-postgres-test-invalid-pg",
		},
	})

	// At the end of the test, run `terraform destroy` to clean up any resources that were created
	defer terraform.Destroy(t, terraformOptions)

	// This will run `terraform init` and `terraform apply` and fail the test if there are any errors
	_, err := terraform.InitAndApplyE(t, terraformOptions)

	// Expect TF apply to error. If not fail the test.
	if err == nil {
		t.Fatal()
	}

}
